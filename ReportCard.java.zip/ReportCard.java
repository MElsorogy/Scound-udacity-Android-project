package com.example.mohamed.reportcardapp;

/**
 * Created by mohamed on 21/07/17.
 */

public class ReportCard {

    private String studentSSN;
    private String studentName;
    private String studentCourse;
    private int studentGrade;

    public ReportCard(){

    }

    public ReportCard(String studentSSN, String studentName, String studentCourse, int studentGrade) {
        this.studentSSN = studentSSN;
        this.studentName = studentName;
        this.studentCourse = studentCourse;
        this.studentGrade = studentGrade;
    }
    public String getStudentSSN() {
        return studentSSN;
    }

    public void setStudentSSN(String studentSSN) {
        this.studentSSN = studentSSN;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentCourse() {
        return studentCourse;
    }

    public void setStudentCourse(String studentCourse) {
        this.studentCourse = studentCourse;
    }

    public int getStudentGrade() {
        return studentGrade;
    }

    public void setStudentGrade(int studentGrade) {
        this.studentGrade = studentGrade;
    }
    private char getClassGrade (int grade){
        char letterGrade = '#';

        if(grade >= 85 && grade <= 100)
            letterGrade = 'A';
        else if(grade >= 75 && grade < 85)
            letterGrade = 'B';
        else if(grade >= 65 && grade < 75)
            letterGrade = 'C';
        else if(grade >= 50 && grade < 65)
            letterGrade = 'D';
        else
            letterGrade = 'F';

        return  letterGrade;
    }

    @Override
    public String toString() {
        return new String ("\nStudent SSN: " + this.studentSSN +
                ", Student Name: "+this.studentName+
                ", Student Course: " + this.studentCourse+
                ", Student Grade: " + this.studentGrade+
                ", Student Class ( " +this.getClassGrade(this.studentGrade) +" ).\n" );
    }
}
